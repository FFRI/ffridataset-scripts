#
# (c) FFRI Security, Inc., 2020-2024 / Author: FFRI Security, Inc.
#
if __name__ == "__main__":
    from .cli import main

    main()
